import 'package:flutter/material.dart';

class spage extends StatefulWidget {
  const spage({Key? key}) : super(key: key);

  @override
  State<spage> createState() => _spageState();
}

class _spageState extends State<spage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
    );
  }
}
